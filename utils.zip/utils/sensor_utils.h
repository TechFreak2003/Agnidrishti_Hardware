#ifndef SENSOR_UTILS_H
#define SENSOR_UTILS_H

#include <DHT.h>
#include "config.h"

DHT dht(DHTPIN, DHTTYPE);

void initSensors() {
  dht.begin();
  pinMode(FLAME_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
}

float readTemperature() {
  return dht.readTemperature();
}

float readHumidity() {
  return dht.readHumidity();
}

int readGasLevel() {
  return analogRead(MQ2_PIN);
}

bool isFireDetected() {
  return digitalRead(FLAME_PIN) == LOW;
}

#endif
