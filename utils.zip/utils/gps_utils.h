#ifndef GPS_UTILS_H
#define GPS_UTILS_H

#include <TinyGPSPlus.h>
#include "config.h"

TinyGPSPlus gps;
HardwareSerial SerialGPS(1);

void initGPS() {
  SerialGPS.begin(9600, SERIAL_8N1, GPS_RX, GPS_TX);
}

String getLocation() {
  while (SerialGPS.available()) {
    gps.encode(SerialGPS.read());
  }

  if (gps.location.isValid()) {
    return String(gps.location.lat(), 6) + "," + String(gps.location.lng(), 6);
  } else {
    return "Unavailable";
  }
}

#endif
